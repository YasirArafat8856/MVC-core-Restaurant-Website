﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Restaurant.Data;
using Restaurant.ViewModel;

namespace Restaurant.Controllers
{
    [Authorize]
    public class RoleController : Controller
    {
        private RoleManager<IdentityRole> roleManager { get; set; }
        private readonly UserManager<ApplicationUser> userManager;
        public RoleController(RoleManager<IdentityRole> roleManager, UserManager<ApplicationUser> userManager)
        {
            this.roleManager = roleManager;
            this.userManager = userManager;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult RoleList()
        {
            var roleList = roleManager.Roles.ToList();
            return View(roleList);
        }
        [HttpGet]
        
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        
        public async Task<IActionResult> Create(RoleVm vm)
        {
            IdentityRole identityRole = new IdentityRole
            {
                Name = vm.RoleName
            };
            if (ModelState.IsValid)
            {
                IdentityResult result = await roleManager.CreateAsync(identityRole);
                if (result.Succeeded)
                {
                    return RedirectToAction("RoleList");
                }
                if (result.Errors.Count() > 0)
                {
                    foreach (var s in result.Errors)
                    {
                        ModelState.AddModelError("", s.ToString());
                    }
                }
            }
            return View(identityRole);
        }

        public IActionResult DisplayRoleUser()
        {
            try
            {
                var list = userManager.Users.ToList();
                ViewBag.Userlist = new SelectList(list, "Id", "UserName");
                ViewBag.RoleList = new SelectList(roleManager.Roles, "Name", "Name");
            }
            catch (Exception ex)
            {
                ViewBag.fmessage = "Something went wrong!";
                ViewBag.error = ex.Message;
            }
            return View();
        }
        public async Task<IActionResult> AssignRole(string Userlist, IEnumerable<string> roles)
        {
            try
            {
                var list = userManager.Users.ToList();
                ViewBag.userList = new SelectList(list, "Id", "UserName");
                ViewBag.RoleList = new SelectList(roleManager.Roles, "Name", "Name");
                var user = await userManager.FindByIdAsync(Userlist);
                IdentityResult result = await userManager.AddToRolesAsync(user, roles);
                if (result.Succeeded)
                {
                    ViewBag.result = user.UserName + " successfully assigned to role " + roles;
                }
                if (result.Errors.Count() > 0)
                {
                    foreach (var s in result.Errors)
                    {
                        ViewBag.fmessage = "Something went wrong!";
                        ViewBag.error = s.ToString();
                    };
                }
            }
            catch (Exception ex)
            {
                ViewBag.fmessage = "Something went wrong!";
                ViewBag.error = ex.Message;
            }
            return View("DisplayRoleuser");
        }
        public async Task<IActionResult> ShowRoleNuser()
        {
            List<UserRoleVm> userRoleList = new List<UserRoleVm>();
            var users = userManager.Users.ToList();
            string roleName = "";
            foreach (var u in users)
            {
                UserRoleVm userVM = new UserRoleVm();

                var roles = await userManager.GetRolesAsync(u);
                foreach (var item in roles)
                {
                    roleName = string.Join(",", item);
                }
                userVM.Username = u.UserName;
                userVM.Role = roleName;

                userRoleList.Add(userVM);
            }
            return View(userRoleList);
        }
    }
}
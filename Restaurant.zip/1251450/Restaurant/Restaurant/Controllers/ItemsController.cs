﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Restaurant.Data;
using Restaurant.ViewModel;

namespace Restaurant.Controllers
{
    public class ItemsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IHostingEnvironment _hosting;

        public ItemsController(ApplicationDbContext context, IHostingEnvironment hosting)
        {
            _context = context;
            this._hosting = hosting;
        }

        // GET: Items
        public IActionResult Index()
        {
            //return View(await _context.Items.ToListAsync());
            return View();
        }
        public JsonResult Get()
        {
            var data = _context.Items.ToList();
            return Json(data);
        } 
        public JsonResult GetByid(int id)
        {
            var data = _context.Items.Find(id);
            return Json(data);
        }
        public IActionResult DeleteItem(int id)
        {
            var data = _context.Items.Find(id);
            _context.Items.Remove(data);
            if (_context.SaveChanges() > 0)
            {
                return Json(new { result = "Success" });
            }
            else
            {
                return Json(new { result = "Failed" });
            }
        }

        [HttpPost]
        public IActionResult AddItem(ItemVm vm,ICollection<IFormFile> files)
        {
        //    if (!ModelState.IsValid)
        //    {
        //        ModelState.AddModelError("", "Invalid Model");
        //        var message = string.Join(" | ", ModelState.Values
        //.SelectMany(v => v.Errors)
        //.Select(e => e.ErrorMessage));
        //        return View("Index", vm);
        //    }
            var uplodPath = Path.Combine(_hosting.WebRootPath, "images");
            Item item = new Item
            {
                Name = vm.Name,
                Price = vm.Price
            };
            foreach(var file in files)
            {
                
                if (file != null && file.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString() + file.FileName;
                    using(var f =new FileStream(Path.Combine(uplodPath, fileName), FileMode.Create))
                    {
                        file.CopyTo(f);
                        item.Picture = "/images/" + fileName;
                    }
                }
            }
            _context.Items.Add(item);
            if (_context.SaveChanges() > 0)
            {
                return Json(new { result = "Success" });
            }
            else
            {
                return Json(new { result = "Failed" });
            }
        }
        [HttpPost]
        public IActionResult UpdateItem(ItemVm vm, IEnumerable<IFormFile> files)
        {
            //if (!ModelState.IsValid)
            //{
            //    ModelState.AddModelError("", "Invalid");
            //    return View("Index", vm);
            //}
            var uplodPath = Path.Combine(_hosting.WebRootPath, "images");
            Item item = new Item
            {
                Id=vm.Id,
                Name = vm.Name,
                Price = vm.Price,
                Picture=vm.Picture
            };
            foreach (var file in files)
            {

                if (file != null && file.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString() + file.FileName;
                    using (var f = new FileStream(Path.Combine(uplodPath, fileName), FileMode.Create))
                    {
                        file.CopyTo(f);
                        item.Picture = "/images/" + fileName;
                    }
                }
            }
            //_context.Items.Add(item);
            _context.Entry(item).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            if (_context.SaveChanges() > 0)
            {
                return Json(new { result = "Success" });
            }
            else
            {
                return Json(new { result = "Failed" });
            }
        }

        // GET: Items/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var item = await _context.Items
                .FirstOrDefaultAsync(m => m.Id == id);
            if (item == null)
            {
                return NotFound();
            }

            return View(item);
        }

        // GET: Items/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Items/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Price,Picture")] Item item)
        {
            if (ModelState.IsValid)
            {
                _context.Add(item);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(item);
        }

        // GET: Items/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var item = await _context.Items.FindAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            return View(item);
        }

        // POST: Items/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Price,Picture")] Item item)
        {
            if (id != item.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(item);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ItemExists(item.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(item);
        }

        // GET: Items/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var item = await _context.Items
                .FirstOrDefaultAsync(m => m.Id == id);
            if (item == null)
            {
                return NotFound();
            }

            return View(item);
        }

        // POST: Items/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var item = await _context.Items.FindAsync(id);
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ItemExists(int id)
        {
            return _context.Items.Any(e => e.Id == id);
        }
    }
}

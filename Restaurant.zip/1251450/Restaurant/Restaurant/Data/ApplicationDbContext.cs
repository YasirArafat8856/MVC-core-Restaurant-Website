﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Restaurant.Data;
using Restaurant.ViewModel;

namespace Restaurant.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Restaurant.Data.Customer> Customer { get; set; }
        public DbSet<Restaurant.Data.Item> Items { get; set; }
        public DbSet<Restaurant.Data.Order> Orders { get; set; }
        public DbSet<Restaurant.ViewModel.ItemVm> ItemVm { get; set; }
    }

    public class ApplicationUser:IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }
        public string Picture { get; set; }
        [NotMapped]
        public IFormFile ImgFile { get; set; }

    }
    public class Item
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Picture { get; set; }
        [NotMapped]
        public IFormFile ImgFile { get; set; }
        public virtual Order Order { get; set; }
        //public IList<Order> Order { get; set; }
    }
    public  class Customer
    {
        public int ID { get; set; }
        [Required]
        public string Cus_Name { get; set; }
        public string Cus_Address { get; set; }
        public string Cus_Contact_NO { get; set; }
        public string Cus_Email { get; set; }
        public virtual Order Order { get; set; }
        //public ICollection<Item> Items { get; set; }
        //public IList<Order> Order { get; set; }
    }
    public  class Order
    {
        public int ID { get; set; }
        [ForeignKey("Customer")]
        public int Cus_Id { get; set; }
        [ForeignKey("Item")]
        public int Item_Id { get; set; }
        public DateTime OrderDate { get; set; }
        public int Quantity { get; set; }
        public decimal Total_Price { get; set; }
        public ICollection<Item> Items { get; set; }
        public ICollection<Customer> Customers { get; set; }
        //public Item Items { get; set; }
        //public Customer Customers { get; set; }
    }
}
